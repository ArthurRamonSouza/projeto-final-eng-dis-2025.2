import { defineConfig } from "vitest/config";

export default defineConfig({
    test: {
        environment: "node",
        setupFiles: ["./src/test/env-bootstrap.ts", "./src/test/setup.ts"],
        include: ["src/**/*.test.ts"],
    },
});
